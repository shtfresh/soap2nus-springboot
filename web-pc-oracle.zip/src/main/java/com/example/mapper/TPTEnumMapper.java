package com.example.mapper;

import java.util.Map;


public interface TPTEnumMapper {
    
	public Map<String, String> getEnum();
}